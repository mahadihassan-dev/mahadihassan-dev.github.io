"use strict"

// form Initializing

//user first name imported here
const UserFirstName = document.getElementById('userFirstName');
UserFirstName.addEventListener('keyup', validate);

//user Last name imported here
const UserLastName = document.getElementById('userLastName');
UserLastName.addEventListener('keyup', validate);

//user ID name imported here
const UserIdName = document.getElementById('userIDName');
UserIdName.addEventListener('keyup', validate);

// User Email Imported
const UserEmailAddress = document.getElementById('userEmail');
UserEmailAddress.addEventListener('keyup', validate);

// User Phone Number
const UserPhonenumber = document.getElementById('userPhone');
UserPhonenumber.addEventListener('keyup', validate);

// User Primary Password
const UserPrimaryPassword = document.getElementById('userPrimaryPassword');
UserPrimaryPassword.addEventListener('keyup', validate);

// User Password Confirmation
const UserConfirmPassword = document.getElementById('userConfirmPassword');
UserConfirmPassword.addEventListener('keyup', validate);

// User Agreement Confirmation
const UserConfrmAgreement = document.getElementById('userAgreement');
UserConfrmAgreement.addEventListener('keyup', validate);


const UserFormSubmission = document.getElementById('userStepNextButton'); //User Submission Imported here
